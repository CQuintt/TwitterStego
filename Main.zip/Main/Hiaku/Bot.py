import tweepy
class Bot(object):
	
	def connect(self):
		"""Establish a connection to the users Twitter account"""
		API_key = "u1NpPWoQ0klxIE1tnEfeeKfLa"
		API_secret_key = "XxFJecfOJtnG4WdLgMAvGPNkyEmSavw8tPfIExR8VCURGV4Rbn"
		access_token = "1088648194555289600-weVaU8a1hTZ8st6zUfVaQvfiL8L09M"
		access_token_secret = "afKljvXSZzyBHwHDsgwCGE6BdBSuq2K2qRuK5Js92vjLy"

		authentication = tweepy.OAuthHandler(API_key, API_secret_key)
		authentication.set_access_token(access_token, access_token_secret)

		api = tweepy.API(authentication)

		return api

	def post_tweet(self,api,currentHaiku):

		haiku = ""
		for word in currentHaiku:
			haiku = haiku + word + " "
		print(haiku)
		api.update_status(haiku)