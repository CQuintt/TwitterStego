import tweepy
class Bot(object):


	
	def connect(self,API_key, API_secret_key, access_token, access_token_secret):
		"""Establish a connection to the users Twitter account"""
		authentication = tweepy.OAuthHandler(API_key, API_secret_key)
		authentication.set_access_token(access_token, access_token_secret)

		api = tweepy.API(authentication)

		return api

	def post_tweet(self,api,message):
		api.update_status(message)