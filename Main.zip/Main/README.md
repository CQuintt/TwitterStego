# TwitterStego
Linguistic Steganography tool used to hide secret messages within tweets using the Twitter API
